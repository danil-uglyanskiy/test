module.exports = {
  ApiUrl: process.env.REACT_APP_API_URL
};
