import ru from './ru';

export default { ru };
