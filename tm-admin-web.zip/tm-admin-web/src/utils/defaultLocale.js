export const locale = 'ru';
