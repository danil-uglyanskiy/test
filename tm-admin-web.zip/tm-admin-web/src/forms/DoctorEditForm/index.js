import BaseForm from 'forms/BaseForm';
import fields from './fields';

class DoctorEditForm extends BaseForm {}

export { fields };

export default DoctorEditForm;
