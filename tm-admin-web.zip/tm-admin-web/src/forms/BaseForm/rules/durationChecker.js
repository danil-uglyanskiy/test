export default value => {
    return ((value % 5) === 0);
};