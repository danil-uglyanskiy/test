
function slotsMapper(slots) {
    return slots;
}

export default slotsMapper;