export { default as slotsMapper } from './slotsMapper';
