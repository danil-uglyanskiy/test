export { default } from './Slot';
