export { default } from './EmptySlot';
