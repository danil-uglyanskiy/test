export { default } from './DailySlots';
