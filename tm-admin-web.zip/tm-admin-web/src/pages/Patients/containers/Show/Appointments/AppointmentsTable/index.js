export { default } from './AppointmentsTable';
