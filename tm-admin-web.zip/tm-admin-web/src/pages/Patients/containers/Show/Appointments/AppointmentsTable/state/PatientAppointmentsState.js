import BaseAppointmentState from 'pages/Patients/containers/Show/state/AppointmentsState';

class PatientAppointmentsState extends BaseAppointmentState {}

export default PatientAppointmentsState;