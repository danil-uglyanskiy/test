export { default } from './InfoPage';
