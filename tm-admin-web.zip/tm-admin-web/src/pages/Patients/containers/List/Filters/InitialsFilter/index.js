export { default as InitialsFilter } from './InitialsFilter';
