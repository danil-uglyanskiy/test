export { default } from './PatientsList';
