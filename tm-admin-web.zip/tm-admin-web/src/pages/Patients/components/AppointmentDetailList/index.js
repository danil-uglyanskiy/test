export { default } from './AppointmentDetailList';
