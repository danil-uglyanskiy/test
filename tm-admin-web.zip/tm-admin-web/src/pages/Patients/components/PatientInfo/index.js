export { default } from './PatientInfo';
