export { default as PatientInfo } from './PatientInfo';
export { default as AppointmentDetailList } from './AppointmentDetailList';
