export { default } from './Patients';
