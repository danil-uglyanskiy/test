export { default as App } from './App';
export { default as Doctors } from './Doctors';
export { default as Schedules } from './Schedules';
export { default as Appointments } from './Appointments'; 
export { default as Patients } from './Patients';
