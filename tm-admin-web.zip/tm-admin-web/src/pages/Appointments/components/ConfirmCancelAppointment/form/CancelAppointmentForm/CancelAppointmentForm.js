import BaseForm from 'forms/BaseForm';
import fields from './fields';

class CancelAppointmentForm extends BaseForm {

  setup(){
    return fields;
  }
}

export default CancelAppointmentForm;
