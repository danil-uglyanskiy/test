export { default } from './AppointmentsInfo';
