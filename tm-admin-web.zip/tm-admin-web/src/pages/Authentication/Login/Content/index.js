export { default } from "./Content";
