import Auth from '.';

export default {
  component: Auth,
  name: 'Auth',
};
