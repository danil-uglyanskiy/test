export { default } from './Details';
