export { default } from './DoctorsList';
