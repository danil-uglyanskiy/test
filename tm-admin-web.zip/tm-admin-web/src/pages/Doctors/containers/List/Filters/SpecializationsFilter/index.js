export { default as SpecializationsFilter } from './SpecializationsFilter';
