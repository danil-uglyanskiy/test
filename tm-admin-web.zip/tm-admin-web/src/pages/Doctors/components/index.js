export { default as DoctorForm } from './DoctorForm';
