export { default as StubbedComponent } from './StubbedComponent';
export { default } from './ComponentStub';
