export { default } from './StubbedComponent';
