export { default } from './DetailList';
