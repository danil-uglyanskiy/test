const fields = [
  'filters',
  'filters[]',
  'filters[].name',
  'filters[].value'
];

const values = {
  filters: []
};

export default {
  fields,
  values
};