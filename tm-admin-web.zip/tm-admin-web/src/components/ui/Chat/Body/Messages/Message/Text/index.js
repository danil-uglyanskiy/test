export { default } from './Text';
