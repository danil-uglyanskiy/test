export { default as Buttons } from './Buttons';
export { default as Content } from './Content';
export { default as Footer } from './Footer';
export { default as Title } from './Title';
