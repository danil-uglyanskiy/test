import Input from './Input';

export default {
  component: Input,
  props: {
    field: {
      error: true,
    },
  },
};
