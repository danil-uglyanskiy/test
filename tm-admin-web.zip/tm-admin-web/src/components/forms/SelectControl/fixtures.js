import Select from './SelectControl';

export default {
  component: Select,
  name: 'Select',
  props: {
    text: 'Показывать все'
  }
};