export {
  Table, TableHead, TableBody, TableRow, TableHeadCell, TableBodyCell,
} from './Table';
