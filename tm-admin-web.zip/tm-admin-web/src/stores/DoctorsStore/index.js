export { default as DoctorsStore } from './DoctorsStore';
export { default as DoctorStore } from './DoctorStore';
